//
//  ConsoliAdsMediationDelegate.h
//  ConsoliAdsMediation
//
//  Created by FazalElahi on 26/10/2018.
//  Copyright © 2018 ConsoliAds. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol ConsoliAdsMediationDelegate <NSObject>

@optional
- (void)onConsoliAdsInitializationSuccess:(BOOL)status;
- (void)onErrorGetFromEngine;
- (void)onSyncUserDeviceCompleted:(NSString *)response;

@end

@protocol ConsoliAdsMediationInterstitialAdDelegate <NSObject>

@optional
- (void)onInterstitialAdShown;
- (void)onInterstitialAdClicked;
- (void)onInterstitialAdClosed;
- (void)onInterstitialAdFailedToShow;

- (void)onVideoAdShown;
- (void)onVideoAdFailedToShow;
- (void)onVideoAdClicked;
- (void)onVideoAdClosed;

@end

@protocol ConsoliAdsMediationRewardedAdDelegate <NSObject>

@optional
- (void)onRewardedVideoAdLoaded;
- (void)onRewardedVideoAdFailToLoad;
- (void)onRewardedVideoAdShown;
- (void)onRewardedVideoAdCompleted;
- (void)onRewardedVideoAdClicked;
- (void)onRewardedVideoAdFailToShow;
- (void)onRewardedVideoAdClosed;

@end

@protocol UnityCommunication <NSObject>
@optional

-(void)getDataFromPlatform:(NSString*)os;
@end

