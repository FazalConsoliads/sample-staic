//
//  CAAdChoicesView.h
//  ConsoliAd
//
//  Created by FazalElahi on 17/12/2018.
//  Copyright © 2018 FazalElahi. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CAAdChoicesView : UIView

@end

NS_ASSUME_NONNULL_END
