//
//  IconAdView.h
//  ConsoliAd
//
//  Created by rehmanaslam on 14/12/2018.
//  Copyright © 2018 FazalElahi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "IconAdView.h"
#import "IconAdBase.h"
#import "ConsoliAdsIconAdSizes.h"

NS_ASSUME_NONNULL_BEGIN

@interface IconAdView : UIView

//- (instancetype)initWithAd:(IconAdBase *)iconAdBase;
- (instancetype)initWithAd:(IconAdBase *)iconAdBase animationType:(int)animationType;
- (void)destroyIconAd;

@end

NS_ASSUME_NONNULL_END
