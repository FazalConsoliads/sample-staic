//
//  ConsoliMediation.h
//  ConsoliMediation
//
//  Created by FazalElahi on 19/10/2018.
//  Copyright © 2018 ConsoliAds. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ConsoliAdsMediationDelegate.h"
#import "CANativeAdRequestDelegate.h"
#import <UIKit/UIKit.h>
#import "CAMediatedBannerView.h"
#import "ConsoliAdsMediationIconAdDelegate.h"
#import "IconAdBase.h"

@interface ConsoliAdsMediation : NSObject

@property (nonatomic , retain) NSString * _Nonnull userSignature;
@property (nonatomic , retain) NSString * _Nonnull productName;
@property (nonatomic , retain) NSString * _Nonnull bundleIdentifier;
@property (nonatomic , retain) NSString * _Nonnull bundleVersion;
@property (nonatomic , retain) NSString * _Nonnull asMoreAppsURL;
@property (nonatomic , retain) NSString * _Nonnull asRateUsURL;
@property (nonatomic , retain) NSString * _Nonnull supportEmail;

+ (ConsoliAdsMediation*_Nonnull)sharedInstance ;

- (void)initialize:(BOOL)isDevMode boolUserConsent:(BOOL)userConsent viewController:(UIViewController *_Nullable)viewControler;
- (void)showInterstitial:(NSInteger)sceneIndex viewController:(UIViewController*_Nonnull)viewController;
- (void)showRewardedVideo:(NSInteger)sceneIndex viewController:(UIViewController* _Nonnull)viewController;
- (void)hideAllAds;
- (void)loadRewarded:(NSInteger)sceneIndex;
- (BOOL)isInterstitialAvailable:(NSInteger)sceneIndex;
- (BOOL)isRewardedVideoAvailable:(NSInteger)sceneIndex;
- (void)setDelegate:(id<ConsoliAdsMediationDelegate>_Nonnull)delegate;
- (void)setInterstitialAdDelegate:(id<ConsoliAdsMediationInterstitialAdDelegate>_Nonnull)delegate;
- (void)setRewardedAdDelegate:(id<ConsoliAdsMediationRewardedAdDelegate>_Nonnull)delegate;
- (void)addAdmobTestDevice:(NSString *_Nonnull)deviceId;
- (void)loadNativeAdInViewController:(UIViewController *_Nonnull)viewController
                          sceneIndex:(int)index
                            delegate:(id<CANativeAdRequestDelegate>_Nonnull)delegate;
- (void)showBannerWithIndex:(NSInteger)sceneIndex bannerView:(CAMediatedBannerView*_Nonnull)bannerView viewController:(UIViewController*_Nullable)viewController;
- (void)destroyBannerView:(CAMediatedBannerView*_Nonnull)bannerView;
- (IconAdBase*_Nullable)loadIconAd:(int)sceneIndex viewController:(UIViewController*_Nonnull)viewController delegate:(id<ConsoliAdsMediationIconAdDelegate>_Nonnull)delegate;


@end
