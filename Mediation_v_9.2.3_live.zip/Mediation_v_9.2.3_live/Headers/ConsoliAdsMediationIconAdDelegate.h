//
//  ConsoliAdsMediationIconAdDelegate.h
//  ConsoliAdsMediation
//
//  Created by saira on 18/12/2019.
//  Copyright © 2019 ConsoliAds. All rights reserved.
//


@protocol ConsoliAdsMediationIconAdDelegate <NSObject>

-(void)didCloseIconAd;
-(void)didClickIconAd;
-(void)didDisplayIconAd;
-(void)didRefreshIconAd;
-(void)didLoadIconAd;
-(void)didFailedToLoadIconAd;

@end
